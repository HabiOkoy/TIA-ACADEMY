/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam;

/**
 *
 * @author Xiao You
 */
import java.util.*;
 class InputBarang {
    private String nama;
    private int jumlah;
    private int harga;
    
    public InputBarang(String nama, int jumlah, int harga){
        this.nama = nama;
        this.jumlah = jumlah;
        this.harga = harga;
        
    }
    public String getNama(){
        return nama;
    }
    public int getJumlah(){
        return jumlah;
    }
    public int getHarga(){
        return harga;
    }
    public int getTotal(){
        return jumlah * harga;
    }
    
}

