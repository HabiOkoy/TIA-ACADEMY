/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam;

/**
 *
 * @author Xiao You
 */

import java.util.*;

public class MiniMarket {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String username, password;
        System.out.print("Username : ");
        username = scanner.nextLine();
        System.out.print("Password : ");
        password = scanner.nextLine();

        if (username.equals("Hary") && password.equals("password")) {
            System.out.print("Selamat datang Hary, masukan jumlah data item yang akan dijual : ");
            int jumlahBarang = scanner.nextInt();

            ArrayList<InputBarang> daftarBarang = new ArrayList<>();
            for (int i = 0; i < jumlahBarang; i++) {
                System.out.println("\n-------------- INPUT BARANG --------------");
                System.out.printf("Barang %d\n", i+1);

                System.out.print("Masukan Nama Barang : ");
                String namaBarang = scanner.next();

                System.out.print("Masukan Jumlah Barang : ");
                int jumlah = scanner.nextInt();

                System.out.print("Masukan Harga Satuan : ");
                int hargaSatuan = scanner.nextInt();

                InputBarang barang = new InputBarang(namaBarang, jumlah, hargaSatuan);
                daftarBarang.add(barang);
            }

            System.out.println("\nTampilan");
            int totalBelanja = 0;
            for (InputBarang barang : daftarBarang) {
                int totalHargaBarang = barang.getTotal();
                totalBelanja += totalHargaBarang;

                System.out.printf("%s %d (@%d) Rp. %d\n", barang.getNama(), barang.getJumlah(),
                        barang.getHarga(), totalHargaBarang);
            }

            System.out.println("\n------------------------------------");
            System.out.printf("Total belanja adalah Rp. %d\n", totalBelanja);
        } else {
            System.out.println("Username atau password salah!");
        }
    }
}
