/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam;

/**
 *
 * @author Xiao You
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class Mahasiswa {
    private int id;
    private String nama;
    private int nilai;

    public Mahasiswa(int id, String nama, int nilai) {
        this.id = id;
        this.nama = nama;
        this.nilai = nilai;
    }

    public int getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getNilai() {
        return nilai;
    }

    public void setNilai(int nilai) {
        this.nilai = nilai;
    }

    @Override
    public String toString() {
        return "ID : " + id + "\nNama : " + nama + "\nNilai : " + nilai + "\n";
    }

    public static void main(String[] args) {
        ArrayList<Mahasiswa> daftarMahasiswa = new ArrayList<Mahasiswa>();
        Scanner scanner = new Scanner(System.in);
        int pilihanMenu = 0;
        while (pilihanMenu != 5) {
        System.out.println("=======================================");
        System.out.println("|            PROGRAM JAVA             |");
        System.out.println("|          OBJECT MAHASISWA           |");
        System.out.println("=======================================");
        System.out.println("| MENU                                |");
        System.out.println("| 1. Buat Object Mahasiswa            |");
        System.out.println("| 2. Edit Data Mahasiswa              |");
        System.out.println("| 3. Remove Object Mahasiswa          |");
        System.out.println("| 4. Simpan Laporan Mahasiswa         |");
        System.out.println("| 5. Keluar                           |");
        System.out.println("=======================================");
        System.out.print("Pilih nomor: ");
            pilihanMenu = scanner.nextInt();
            
            switch (pilihanMenu) {
                case 1:
                    System.out.println("=======================================");
                    System.out.println("|             TAMBAH DATA             |");
                    System.out.println("=======================================");
                    System.out.print("Input ID : ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Input Nama : ");
                    String nama = scanner.nextLine();
                    System.out.print("Input Nilai : ");
                    int nilai = scanner.nextInt();
                    Mahasiswa mhsBaru = new Mahasiswa(id, nama, nilai);
                    boolean idSudahAda = false;
                    for (Mahasiswa mhs : daftarMahasiswa) {
                        if (mhs.getId() == id) {
                            idSudahAda = true;
                            break;
                        }
                    }
                    if (!idSudahAda) {
                        daftarMahasiswa.add(mhsBaru);
                        System.out.println("Mahasiswa berhasil ditambahkan.");
                    } else {
                        System.out.println("ID sudah digunakan.");
                    }
                    break;
                case 2:
                    System.out.print("Input ID Mahasiswa : ");
                    int idMahasiswa = scanner.nextInt();
                    scanner.nextLine();
                    Mahasiswa mhsEdit = null;
                    for (Mahasiswa mhs : daftarMahasiswa) {
                        if (mhs.getId() == idMahasiswa) {
                            mhsEdit = mhs;
                            break;
                        }
                    }
                    if (mhsEdit == null) {
                        System.out.println("Mahasiswa tidak ditemukan.");
                    } else {
                        System.out.println("=======================================");
                        System.out.println("|              EDIT DATA              |");
                        System.out.println("=======================================");
                        System.out.println("| Pilih Data Yang Ingin Di Ubah       |");
                        System.out.println("| 1. Nama                             |");
                        System.out.println("| 2. Nilai                            |");
                        System.out.println("=======================================");
                        System.out.print("Pilih Anda: ");
                        int pilihanEdit = scanner.nextInt();
                        scanner.nextLine();
                        switch (pilihanEdit) {
                            case 1:
                                System.out.print("Nama baru : ");
                                String namaBaru = scanner.nextLine();
                                mhsEdit.setNama(namaBaru);
                                System.out.println("Nama berhasil diubah.");
                                break;
                            case 2:
                                System.out.print("Nilai baru : ");
                                int nilaiBaru = scanner.nextInt();
                                mhsEdit.setNilai(nilaiBaru);
                                System.out.println("Nilai berhasil diubah.");
                                break;
                            default:
                                System.out.println("Pilihan tidak valid.");
                                break;
                        }
                    }
                    break;
                case 3:
                    System.out.println("=======================================");
                    System.out.println("|             HAPUS DATA              |");
                    System.out.println("=======================================");
                    System.out.print("Masukan ID yang ingin dihapus : ");
                    int idHapus = scanner.nextInt();
                    boolean idDitemukan = false;
                    for (Mahasiswa mhs : daftarMahasiswa) {
                        if (mhs.getId() == idHapus) {
                            daftarMahasiswa.remove(mhs);
                            idDitemukan = true;
                            System.out.println("Mahasiswa berhasil dihapus.");
                            break;
                        }
                    }
                    if (!idDitemukan) {
                        System.out.println("Mahasiswa tidak ditemukan.");
                    }
                    break;
                case 4:
                    System.out.println("=======================================");
                    System.out.println("|             SIMPAN DATA             |");
                    System.out.println("=======================================");
                    System.out.print("Masukkan directory untuk menyimpan laporan : ");
                    String directory = scanner.next();
                    System.out.print("Masukkan nama file untuk menyimpan laporan : ");
                    String filename = scanner.next();
                    try {
                        FileWriter fileWriter = new FileWriter(directory + "/" + filename);
                        for (Mahasiswa mhs : daftarMahasiswa) {
                            fileWriter.write(mhs.toString());
                        }
                        fileWriter.close();
                        System.out.println("Laporan berhasil disimpan di " + directory + "/" + filename);
                    } catch (IOException e) {
                        System.out.println("Terjadi kesalahan saat menyimpan laporan.");
                    }
                    break;
                case 5:
                    System.out.println("Program selesai.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
        }
    }
}

