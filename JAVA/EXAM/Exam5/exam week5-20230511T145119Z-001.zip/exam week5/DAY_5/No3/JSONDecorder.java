/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam.DAY_5.No3;

/**
 *
 * @author Xiao You
 */
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class JSONDecorder {
    public static void main(String[] args) {
        String jsonString = "{\"mahasiswa\":[{\"name\":\"John\",\"Nilai\":[7,8,9]},{\"name\":\"Anna\",\"Nilai\":[9,7,7]},{\"name\":\"Peter\",\"Nilai\":[6,5,6]}]}";
        JSONObject jsonObject = new JSONObject(jsonString);
        JSONArray jsonArray = jsonObject.getJSONArray("mahasiswa");

        ArrayList<String> names = new ArrayList<>();
        ArrayList<ArrayList<Integer>> grades = new ArrayList<>();

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            String name = obj.getString("name");
            names.add(name);
            JSONArray nilaiArray = obj.getJSONArray("Nilai");
            ArrayList<Integer> nilaiList = new ArrayList<>();
            for (int j = 0; j < nilaiArray.length(); j++) {
                nilaiList.add(nilaiArray.getInt(j));
            }
            grades.add(nilaiList);
        }

        // Print hasilnya
        for (int i = 0; i < names.size(); i++) {
            System.out.println(names.get(i) + ": " + grades.get(i));
        }
    }
}
