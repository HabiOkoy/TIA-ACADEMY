/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam.DAY_5.No2;

/**
 *
 * @author Xiao You
 */
import org.json.JSONArray;
import org.json.JSONObject;

public class json {
    public static void main(String[] args) {
        // membuat objek JSON
        JSONObject obj = new JSONObject();

        // membuat objek array JSON
        JSONArray employees = new JSONArray();

        // membuat objek JSON untuk setiap karyawan
        JSONObject john = new JSONObject();
        john.put("name", "John");
        john.put("age", 30);
        john.put("city", "New York");

        JSONObject anna = new JSONObject();
        anna.put("name", "Anna");
        anna.put("age", 25);
        anna.put("city", "London");

        JSONObject peter = new JSONObject();
        peter.put("name", "Peter");
        peter.put("age", 36);
        peter.put("city", "Madrid");

        // menambahkan objek JSON karyawan ke array JSON
        employees.put(john);
        employees.put(anna);
        employees.put(peter);

        // menambahkan array JSON karyawan ke objek JSON
        obj.put("employees", employees);

        // menghasilkan JSON
        String json = obj.toString();
        System.out.println(json);
    }
}

