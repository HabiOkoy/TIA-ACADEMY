/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam.DAY_4.No2;

/**
 *
 * @author Xiao You
 */
class Parent {
    public void home() {
        System.out.println("Parent's Home");
    }
    
    public void car() {
        System.out.println("Parent's Car");
    }
}





