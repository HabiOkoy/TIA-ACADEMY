/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam.DAY_4.No1;

/**
 *
 * @author Xiao You
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

class Worker {
    private int IDKaryawan;
    private String Nama;
    
    public Worker(int IDKaryawan, String Nama) {
        this.IDKaryawan = IDKaryawan;
        this.Nama = Nama;
    }
    
    public int getIDKaryawan() {
        return IDKaryawan;
    }
    
    public String getNama() {
        return Nama;
    }
    
    public void setIDKaryawan(int IDKaryawan) {
        this.IDKaryawan = IDKaryawan;
    }
    
    public void setNama(String Nama) {
        this.Nama = Nama;
    }
}

class Staff extends Worker {
    private String Jabatan;
    
    public Staff(int IDKaryawan, String Nama, String Jabatan) {
        super(IDKaryawan, Nama);
        this.Jabatan = Jabatan;
    }
    
    public String getJabatan() {
        return Jabatan;
    }
    
    public void setJabatan(String Jabatan) {
        this.Jabatan = Jabatan;
    }
}



