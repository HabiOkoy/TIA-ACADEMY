/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam.DAY_4.No1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

/**
 *
 * @author Xiao You
 */
public class Stafff {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Staff> listStaff = new ArrayList<>();
        int choice = 0;
        
        do {
             System.out.println("=======================================");
             System.out.println("|            PROGRAM JAVA             |");
             System.out.println("|              KARYAWAN               |");
             System.out.println("=======================================");
             System.out.println("| MENU                                |");
             System.out.println("| 1. INPUT DATA STAFF                 |");
             System.out.println("| 2. TAMPILKAN LAPORAN STAFF          |");
             System.out.println("| 3. EXIT                             |");
             System.out.println("=======================================");
             System.out.print("Pilih nomor: ");
            choice = sc.nextInt();
            
            switch (choice) {
                case 1:
                    System.out.println("=======================================");
                    System.out.println("|          INPUT DATA STAFF           |");
                    System.out.println("=======================================");
                    System.out.print("Masukkan ID Karyawan: ");
                    int IDKaryawan = sc.nextInt();
                    System.out.print("Masukkan Nama: ");
                    String Nama = sc.next();
                    System.out.print("Masukkan Jabatan: ");
                    String Jabatan = sc.next();
                    
                    Staff staff = new Staff(IDKaryawan, Nama, Jabatan);
                    listStaff.add(staff);
                    System.out.println("Data Staff berhasil diinput.");
                    break;
                
                case 2:
                    System.out.println("=======================================");
                    System.out.println("|            LAPORAN STAFF            |");
                    System.out.println("=======================================");
                    System.out.println("ID\tNama\t\tJabatan");
                    Collections.sort(listStaff, Comparator.comparing(Staff::getIDKaryawan));
                    for (Staff s : listStaff) {
                        System.out.printf("%d\t%-10s\t%s\n", s.getIDKaryawan(), s.getNama(), s.getJabatan());
                    }
                    break;
                    
                case 3:
                    System.out.println("Terima kasih.");
                    break;
                    
                default:
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
            
            System.out.println();
        } while (choice != 3);
    }
}