/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exam.DAY_4.No3;

/**
 *
 * @author Xiao You
 */
class Parent {
    String name = "Mr. USD";
    int money = 2000000;
    
    public void home() {
        System.out.println("Parent's home");
    }
    
    public void car() {
        System.out.println("Parent's Car");
    }
}





